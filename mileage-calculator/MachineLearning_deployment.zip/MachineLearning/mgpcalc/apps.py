from django.apps import AppConfig


class MgpcalcConfig(AppConfig):
    name = 'mgpcalc'
